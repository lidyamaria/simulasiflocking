const flock = []; //array yg akan diisikan banyak kendaraan
let alignSlider, cohesionSlider, separationSlider;
let population;
function setup() {
  createCanvas(400, 400);
  //createSlider(min, max, nilai_skrg, jarak antar nilai)
  
  s=createInput("200");
  s.position(10,30)
  
  alignSlider = createSlider(0,5,1,0.1);
  cohesionSlider = createSlider(0,5,1,0.1);
  separationSlider = createSlider(0,5,1,0.1);
  
  population = 200;
  for (let i=0; i<population;i++){
    flock.push(new Boid());
  }
}

function draw() {
  background(100,149,237);
  text("posisi",70,20)
  text("Align",60,390)
  text("Cohesion",170,390)
  text("Separation",290,390)
  text("Tugas MK Visualisasi dalam Sains",210,20)
  text("Simulasi Flocking",210,40)
  text("Nama: Lidya Maria Octafia",210,60)
  text("Nim: 119160064",210,80)
  text("Prodi: Matematika",210,100)
  
  for (let boid of flock){
    boid.edges();
    boid.flock(flock)
    boid.update();
    boid.show();
  }
}